import React from 'react';

const Checkout = () => {
    return (
        <div>
            <h1>Please to Checkout you booking</h1>
        </div>
    );
};

export default Checkout;